package com.adanidigital.machinetest.utils

object CommonUtils {
}
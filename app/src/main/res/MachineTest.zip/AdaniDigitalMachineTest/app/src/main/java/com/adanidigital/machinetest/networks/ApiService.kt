package com.adanidigital.machinetest.networks

interface ApiService {

}